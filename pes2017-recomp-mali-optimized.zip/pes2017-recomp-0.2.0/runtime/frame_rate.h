#pragma once
// PES17_FPS_LIMIT: how many frames a second the title draws at most.
// PES17_GAME_SPEED: Game Speed multiplier in percent (100 = 1x, 150 = 1.5x, 200 = 2x Turbo like PSP).
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <thread>
#include "env.h"

namespace frame_rate
{
    constexpr uint32_t kConsole = 60;

    // com_maxfps: 0 is no limit, and 1000 is the most the title takes.
    inline uint32_t Limit()
    {
        static const uint32_t limit = uint32_t(std::min<uint64_t>(env::Number("PES17_FPS_LIMIT", kConsole), 1000));
        return limit;
    }

    // Game speed in percent: 100 is normal (1.0x), 200 is 2.0x (Turbo speed)
    inline uint32_t SpeedPercent()
    {
        static const uint32_t speed = uint32_t(std::clamp<uint64_t>(env::Number("PES17_GAME_SPEED", 100), 50, 400));
        return speed;
    }

    // Under the console's 60 there is no present hook to take the title off the
    // blank (T_D3D_Present is not located for this title), so the limit is kept
    // where the title submits a frame: VdSwap waits until a frame's length has
    // passed since the last one. Called from the thread that swaps.
    inline void PaceSwap()
    {
        const uint32_t limit = Limit();
        const uint32_t speed = SpeedPercent();
        if (limit == 0) return; // 0 = unthrottled / unlimited FPS
        if (limit >= kConsole && speed == 100) return;
        using clock = std::chrono::steady_clock;
        static clock::time_point next{};
        const auto now = clock::now();
        // Compute period in microseconds scaled by game speed multiplier
        const uint64_t targetRate = (uint64_t(limit) * uint64_t(speed)) / 100ULL;
        if (targetRate == 0) return;
        const auto period = std::chrono::microseconds(1000000ULL / targetRate);
        if (now < next) std::this_thread::sleep_until(next);
        // A frame that ran long does not owe the ones it missed.
        next = (now > next + period) ? now + period : next + period;
    }

    // Frames are retired at the blank, one a blank, as on the console.
    inline bool Console() { return Limit() == kConsole && SpeedPercent() == 100; }
}
